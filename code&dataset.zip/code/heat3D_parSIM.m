function [ T , D , error , K] = heat3D_parSIM( cond , M , d_obs , Q )
%%%%%%%
%% Input
% M: model mesh
% cond: thermal conductivity distribution   
% Q: source vector
% d_obs: observation vector

%% Genrate coefficient matrix
[ K ]=gen_K( M , cond );

%% Calculate the temperature distribution
T=gmres(K,Q,200);

%% Calculate the error between forward modeling and observation
error = std(T - d_obs);

%% diag+sparse error
D=diag(sparse(1./std([log(T),log(d_obs(:,1))],0,2)));

end

