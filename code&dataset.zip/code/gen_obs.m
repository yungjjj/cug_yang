clear
clc
%%%%% forward modeling
%%%%% generate observation data

%% Generate mesh
M.grid.dx = ones(40,1) * 500;
M.grid.dy = ones(10,1) * 500;
M.grid.dz = ones(20,1) * 500;

M.grid.z = [0; cumsum(M.grid.dz)];
M.grid.x = [0; cumsum(M.grid.dx)];
M.grid.y = [0; cumsum(M.grid.dy)];

[ M.N_element , M.Node , M.Num_node ]=gen_mesh( M );

%% Insert anomaly body
ano_big=M.Node(M.Node(:,2)>=9500&M.Node(:,2)<=10500&M.Node(:,3)>=2000&M.Node(:,3)<=3500&M.Node(:,4)>=3000&M.Node(:,4)<=6000,1);
ano_small=M.Node(M.Node(:,2)>=7500&M.Node(:,2)<=12500&M.Node(:,3)>=2000&M.Node(:,3)<=3500&M.Node(:,4)>=6500&M.Node(:,4)<=7000,1);

%% Input thermal conductivity distribution
cond=ones(M.Num_node,4)*3;
cond(ano_big,4)=5;
cond(ano_small,4)=1;
cond(:,1)=M.Node(:,2);
cond(:,2)=M.Node(:,3);
cond(:,3)=M.Node(:,4);

%% Generate coefficient matrix
[ K ] = gen_K( M , cond );

%% Boundary condition
%% Top boundary
T_up = 15;
%% Bottom boundary
q_down = 0.05;

%% Generate source vector
Q = gen_Q( M , q_down , T_up );

%% Calculate temperature distribution
T=gmres(K,Q,200);
