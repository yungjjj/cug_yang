function  fia = gen_fia( M , D , lamda , m , Q , d_obs , m_apr , Wm)

[ K ]=gen_K( M , m );

dm=gmres(K,Q,200);

fia_d = ((dm - d_obs))' * ((dm - d_obs));%%

fia_m = (Wm * (m(:,4) - m_apr))' * (Wm * (m(:,4) - m_apr));

fia = fia_d + lamda * fia_m;

