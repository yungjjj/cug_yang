function [ GTv ] = gen_GTv( M , T , Z)
%%%%%%
%% Output
% GTv: G' * z

e = zeros(M.Num_node,1);
Num_node = M.Num_node;
N_element = M.N_element;
Node = M.Node;
num = 1;

for ele_i = 1 : length(N_element)
    x0=(Node(N_element(ele_i,2),2)+Node(N_element(ele_i,3),2)+Node(N_element(ele_i,4),2)+Node(N_element(ele_i,5),2)+Node(N_element(ele_i,6),2)+Node(N_element(ele_i,7),2)+Node(N_element(ele_i,8),2)+Node(N_element(ele_i,9),2))/8;
    y0=(Node(N_element(ele_i,2),3)+Node(N_element(ele_i,3),3)+Node(N_element(ele_i,4),3)+Node(N_element(ele_i,5),3)+Node(N_element(ele_i,6),3)+Node(N_element(ele_i,7),3)+Node(N_element(ele_i,8),3)+Node(N_element(ele_i,9),3))/8;
    z0=(Node(N_element(ele_i,2),4)+Node(N_element(ele_i,3),4)+Node(N_element(ele_i,4),4)+Node(N_element(ele_i,5),4)+Node(N_element(ele_i,6),4)+Node(N_element(ele_i,7),4)+Node(N_element(ele_i,8),4)+Node(N_element(ele_i,9),4))/8;
    
    %% length of element
    a=abs(Node(N_element(ele_i,4),2)-Node(N_element(ele_i,3),2));
    b=abs(Node(N_element(ele_i,2),3)-Node(N_element(ele_i,6),3));
    c=abs(Node(N_element(ele_i,2),4)-Node(N_element(ele_i,3),4));
    
    %% code of element
    unit_8=N_element(ele_i,2:9);
    
    %% coordinate of local coordinate system
    for Ni=1:8
        kec=(Node(unit_8(Ni),2)-x0)*(2/a);
        eta=(Node(unit_8(Ni),3)-y0)*(2/b);
        sita=(Node(unit_8(Ni),4)-z0)*(2/c);
        
        mu_unit(Ni,:)=[Ni,kec,eta,sita];
    end
    
    for m = 1 : 8
        
        e(unit_8(m)) = 1;
        
        for i=1:8
            for j=1:i
                for l=1:8
                    alfa(l)=mu_unit(i,2)*mu_unit(j,2)*(3+mu_unit(i,3)*mu_unit(j,3)+mu_unit(i,3)*mu_unit(l,3)+mu_unit(j,3)*mu_unit(l,3))*(3+mu_unit(i,4)*mu_unit(j,4)+mu_unit(i,4)*mu_unit(l,4)+mu_unit(j,4)*mu_unit(l,4))/4;
                    beta(l)=mu_unit(i,3)*mu_unit(j,3)*(3+mu_unit(i,2)*mu_unit(j,2)+mu_unit(i,2)*mu_unit(l,2)+mu_unit(j,2)*mu_unit(l,2))*(3+mu_unit(i,4)*mu_unit(j,4)+mu_unit(i,4)*mu_unit(l,4)+mu_unit(j,4)*mu_unit(l,4))/4;
                    gama(l)=mu_unit(i,4)*mu_unit(j,4)*(3+mu_unit(i,2)*mu_unit(j,2)+mu_unit(i,2)*mu_unit(l,2)+mu_unit(j,2)*mu_unit(l,2))*(3+mu_unit(i,3)*mu_unit(j,3)+mu_unit(i,3)*mu_unit(l,3)+mu_unit(j,3)*mu_unit(l,3))/4;
                end

                if i==j
                    line(num)=unit_8(m);column(num)=1;
                    value(num)=Z(unit_8(i),4)*T(unit_8(j))*(b*c/a*alfa+a*c/b*beta+a*b/c*gama)*[e(unit_8(1),1);e(unit_8(2),1);e(unit_8(3),1);e(unit_8(4),1);e(unit_8(5),1);e(unit_8(6),1);e(unit_8(7),1);e(unit_8(8),1)]/288;
                    num=num+1;
                else
                    line(num)=unit_8(m);column(num)=1;
                    value(num)=Z(unit_8(i),4)*T(unit_8(j))*(b*c/a*alfa+a*c/b*beta+a*b/c*gama)*[e(unit_8(1),1);e(unit_8(2),1);e(unit_8(3),1);e(unit_8(4),1);e(unit_8(5),1);e(unit_8(6),1);e(unit_8(7),1);e(unit_8(8),1)]/288;
                    num=num+1;
                    line(num)=unit_8(m);column(num)=1;
                    value(num)=Z(unit_8(j),4)*T(unit_8(i))*(b*c/a*alfa+a*c/b*beta+a*b/c*gama)*[e(unit_8(1),1);e(unit_8(2),1);e(unit_8(3),1);e(unit_8(4),1);e(unit_8(5),1);e(unit_8(6),1);e(unit_8(7),1);e(unit_8(8),1)]/288;
                    num=num+1;
                end
            end
        end
        e = zeros(M.Num_node,1);
    end
    
end
%% Generate G' * z
GTv=-sparse(line,column,value,Num_node,1);