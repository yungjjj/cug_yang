function  alpha_d = armijo(  M , D , lamda , cond , g , Q , d_obs , m_apr , Wm , deltam)
%%%%% Armijo rule
%% Output
% alpha_d: the optimized step length

%% Initial value
alpha_d = 1;

%% Initial m in equation (29)
m0(:,1)=M.Node(:,2);
m0(:,2)=M.Node(:,3);
m0(:,3)=M.Node(:,4);
m0(:,4) = exp ( log( cond(:,4) ) );

%% calculate the objective function under initial m
fia0 = gen_fia( M , D , lamda , m0 , Q , d_obs , m_apr , Wm);

%% m + alpha * delta in equation (29)
m1(:,1)=M.Node(:,2);
m1(:,2)=M.Node(:,3);
m1(:,3)=M.Node(:,4);
m1(:,4) = exp ( log( cond(:,4)) + alpha_d * deltam );

%% calculate the objective function under initial m + alpha * delta
fia1 = gen_fia( M , D , lamda , m1 , Q , d_obs , m_apr , Wm);

%% calculate the right side of equation (29)
g_w = fia0 + 1e-4 * alpha_d * g' * deltam;

%% Start procedure
while (fia1 > fia0 + g_w) % Inequality is satisfied
    
    alpha_d = alpha_d * 0.5;
    
    m1(:,1)=M.Node(:,2);
    m1(:,2)=M.Node(:,3);
    m1(:,3)=M.Node(:,4);
    m1(:,4) = exp ( log( cond(:,4)) + alpha_d * deltam );
    
    fia1 = gen_fia( M , D , lamda , m1 , Q , d_obs , m_apr , Wm);
    
    g_w = fia0 + 1e-4 * alpha_d * g' * deltam;
    
end
    
    