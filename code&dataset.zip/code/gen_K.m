function [ K ] = gen_K( M, cond )
%%%%%% Generate coefficient matrix K
%% Output coefficient matrix K

Num_node = M.Num_node;
N_element = M.N_element;
Node = M.Node;
num = 1;

for ele_i = 1 : length(N_element)
    
    x0=(Node(N_element(ele_i,2),2)+Node(N_element(ele_i,3),2)+Node(N_element(ele_i,4),2)+Node(N_element(ele_i,5),2)+Node(N_element(ele_i,6),2)+Node(N_element(ele_i,7),2)+Node(N_element(ele_i,8),2)+Node(N_element(ele_i,9),2))/8;
    y0=(Node(N_element(ele_i,2),3)+Node(N_element(ele_i,3),3)+Node(N_element(ele_i,4),3)+Node(N_element(ele_i,5),3)+Node(N_element(ele_i,6),3)+Node(N_element(ele_i,7),3)+Node(N_element(ele_i,8),3)+Node(N_element(ele_i,9),3))/8;
    z0=(Node(N_element(ele_i,2),4)+Node(N_element(ele_i,3),4)+Node(N_element(ele_i,4),4)+Node(N_element(ele_i,5),4)+Node(N_element(ele_i,6),4)+Node(N_element(ele_i,7),4)+Node(N_element(ele_i,8),4)+Node(N_element(ele_i,9),4))/8;
    
    %% length of element
    a=abs(Node(N_element(ele_i,4),2)-Node(N_element(ele_i,3),2));
    b=abs(Node(N_element(ele_i,2),3)-Node(N_element(ele_i,6),3));
    c=abs(Node(N_element(ele_i,2),4)-Node(N_element(ele_i,3),4));
    
    %% code of element
    unit_8=N_element(ele_i,2:9);
    for Ni=1:8
        kec=(Node(unit_8(Ni),2)-x0)*(2/a);
        eta=(Node(unit_8(Ni),3)-y0)*(2/b);
        sita=(Node(unit_8(Ni),4)-z0)*(2/c);
        
        mu_unit(Ni,:)=[Ni,kec,eta,sita];
    end
    for i=1:8
        for j=1:i
            for l=1:8
                alfa(l)=mu_unit(i,2)*mu_unit(j,2)*(3+mu_unit(i,3)*mu_unit(j,3)+mu_unit(i,3)*mu_unit(l,3)+mu_unit(j,3)*mu_unit(l,3))*(3+mu_unit(i,4)*mu_unit(j,4)+mu_unit(i,4)*mu_unit(l,4)+mu_unit(j,4)*mu_unit(l,4))/4;
                beta(l)=mu_unit(i,3)*mu_unit(j,3)*(3+mu_unit(i,2)*mu_unit(j,2)+mu_unit(i,2)*mu_unit(l,2)+mu_unit(j,2)*mu_unit(l,2))*(3+mu_unit(i,4)*mu_unit(j,4)+mu_unit(i,4)*mu_unit(l,4)+mu_unit(j,4)*mu_unit(l,4))/4;
                gama(l)=mu_unit(i,4)*mu_unit(j,4)*(3+mu_unit(i,2)*mu_unit(j,2)+mu_unit(i,2)*mu_unit(l,2)+mu_unit(j,2)*mu_unit(l,2))*(3+mu_unit(i,3)*mu_unit(j,3)+mu_unit(i,3)*mu_unit(l,3)+mu_unit(j,3)*mu_unit(l,3))/4;
            end

            if i==j
                line(num)=unit_8(i);column(num)=unit_8(j);
                value(num)=(b*c/a*alfa+a*c/b*beta+a*b/c*gama)*[cond(unit_8(1),4);cond(unit_8(2),4);cond(unit_8(3),4);cond(unit_8(4),4);cond(unit_8(5),4);cond(unit_8(6),4);cond(unit_8(7),4);cond(unit_8(8),4)]/288;
                num=num+1;
            else
                line(num)=unit_8(i);column(num)=unit_8(j);
                value(num)=(b*c/a*alfa+a*c/b*beta+a*b/c*gama)*[cond(unit_8(1),4);cond(unit_8(2),4);cond(unit_8(3),4);cond(unit_8(4),4);cond(unit_8(5),4);cond(unit_8(6),4);cond(unit_8(7),4);cond(unit_8(8),4)]/288;
                num=num+1;
                line(num)=unit_8(j);column(num)=unit_8(i);
                value(num)=(b*c/a*alfa+a*c/b*beta+a*b/c*gama)*[cond(unit_8(1),4);cond(unit_8(2),4);cond(unit_8(3),4);cond(unit_8(4),4);cond(unit_8(5),4);cond(unit_8(6),4);cond(unit_8(7),4);cond(unit_8(8),4)]/288;
                num=num+1;
            end
        end
    end
    
    %% Boundary condition
    %% Bottom boundary
    if Node(unit_8(2),4)==0&& Node(unit_8(3),4)==0&& Node(unit_8(6),4)==0&& Node(unit_8(7),4)==0
        
        unit_4=[unit_8(2);unit_8(3);unit_8(6);unit_8(7)];

        up=[mu_unit(2,:);mu_unit(3,:);mu_unit(6,:);mu_unit(7,:)];
        
        for i=1:4
            for j=1:i

                if i==j
                    line(num)=unit_4(i);column(num)=unit_4(j);
                    value(num)=1*(a*b/144)*(3+up(i,2)*up(j,2))*(3+up(i,3)*up(j,3));
                    num=num+1;
                else
                    line(num)=unit_4(i);column(num)=unit_4(j);
                    value(num)=1*(a*b/144)*(3+up(i,2)*up(j,2))*(3+up(i,3)*up(j,3));
                    num=num+1;
                    line(num)=unit_4(j);column(num)=unit_4(i);
                    value(num)=1*(a*b/144)*(3+up(i,2)*up(j,2))*(3+up(i,3)*up(j,3));
                    num=num+1;
                end
                
            end
        end
    end
    
end

K=sparse(line,column,value,Num_node,Num_node);