function [ Wm , Wmx , Wmy , Wmz ] = gen_Wm( M , alpha )
%%%%%% generate roughness matrix
%% Output
% Wm: roughness matrix
% Wmx: roughness matrix at x direction
% Wmy: roughness matrix at y direction
% Wmz: roughness matrix at z direction

numw = 1;

%% WMX

z = 1;

y = 1;

for x = 1 : length(M.grid.x)
    
    if x == 1
        
        linex(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
        columnx(numw) = M.Node(M.Node(:,2)==M.grid.x(x+1)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
        valuex(numw) = (-1 / M.grid.dx(x)) / ( 1 / M.grid.dx(x));
        numw = numw + 1;
        
        linex(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
        columnx(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
        valuex(numw) = 1;
        numw = numw + 1;
        
    else if x == length(M.grid.x)
            
            linex(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
            columnx(numw) = M.Node(M.Node(:,2)==M.grid.x(x-1)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
            valuex(numw) = (-1 / M.grid.dx(x-1)) / ( 1 / M.grid.dx(x-1));
            numw = numw + 1;
            
            linex(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
            columnx(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
            valuex(numw) = 1;
            numw = numw + 1;
            
        else
            
            %%%WXij
            linex(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
            columnx(numw) = M.Node(M.Node(:,2)==M.grid.x(x+1)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
            valuex(numw) = (-1 / M.grid.dx(x)) / ( 1 / M.grid.dx(x-1) + 1 / M.grid.dx(x));
            numw = numw + 1;
            
            linex(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
            columnx(numw) = M.Node(M.Node(:,2)==M.grid.x(x-1)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
            valuex(numw) = (-1 / M.grid.dx(x-1)) / ( 1 / M.grid.dx(x-1) + 1 / M.grid.dx(x));
            numw = numw + 1;
            
            linex(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
            columnx(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
            valuex(numw) = 1;
            numw = numw + 1;
            
        end
    end
end

L = [];

C = [];

V = [];

for y = 1 : length(M.grid.y)
    
    for z = 1  : length(M.grid.z)
        
        L = [L , linex + (z-1) * length(M.grid.x) + (y-1) * length(M.grid.x) * length(M.grid.z)];
        
        C = [C , columnx + (z-1) * length(M.grid.x) + (y-1) * length(M.grid.x) * length(M.grid.z)];
        
        V = [V , valuex];
        
    end
    
end

Wmx = sparse(L,C,V,M.Num_node,M.Num_node);

clear L C V linex columnx valuex

%% WMY

numw = 1;

z = 1;

x = 1;

for y = 1 : length(M.grid.y)
    
    if y == 1
        
        linex(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
        columnx(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y+1)&M.Node(:,4)==M.grid.z(z),1);
        valuex(numw) = (-1 / M.grid.dy(y)) / ( 1 / M.grid.dy(y));
        numw = numw + 1;
        
        linex(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
        columnx(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
        valuex(numw) = 1;
        numw = numw + 1;
        
    else if y == length(M.grid.y)
            
            linex(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
            columnx(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y-1)&M.Node(:,4)==M.grid.z(z),1);
            valuex(numw) = (-1 / M.grid.dy(y-1)) / ( 1 / M.grid.dy(y-1));
            numw = numw + 1;
            
            linex(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
            columnx(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
            valuex(numw) = 1;
            numw = numw + 1;
            
        else
            
            %%%WXij
            linex(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
            columnx(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y+1)&M.Node(:,4)==M.grid.z(z),1);
            valuex(numw) = (-1 / M.grid.dy(y)) / ( 1 / M.grid.dy(y-1) + 1 / M.grid.dy(y));
            numw = numw + 1;
            
            linex(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
            columnx(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y-1)&M.Node(:,4)==M.grid.z(z),1);
            valuex(numw) = (-1 / M.grid.dy(y-1)) / ( 1 / M.grid.dy(y-1) + 1 / M.grid.dy(y));
            numw = numw + 1;
            
            linex(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
            columnx(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
            valuex(numw) = 1;
            numw = numw + 1;
            
        end
    end
end

L = [];

C = [];

V = [];

for z = 1 : length(M.grid.z)
    
    for x = 1  : length(M.grid.x)
        
        L = [L , linex + (z-1) * length(M.grid.x) + (x-1) * 1];
        
        C = [C , columnx + (z-1) * length(M.grid.x) + (x-1) * 1];
        
        V = [V , valuex];
        
    end
    
end

Wmy = sparse(L,C,V,M.Num_node,M.Num_node);

clear L C V linex columnx valuex

%% WMZ

numw = 1;

y = 1;

x = 1;

for z = 1 : length(M.grid.z)
    
    if z == 1
        
        linex(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
        columnx(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z+1),1);
        valuex(numw) = (-1 / M.grid.dz(z)) / ( 1 / M.grid.dz(z));
        numw = numw + 1;
        
        linex(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
        columnx(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
        valuex(numw) = 1;
        numw = numw + 1;
        
    else if z == length(M.grid.z)
            
            linex(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
            columnx(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z-1),1);
            valuex(numw) = (-1 / M.grid.dz(z-1)) / ( 1 / M.grid.dz(z-1));
            numw = numw + 1;
            
            linex(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
            columnx(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
            valuex(numw) = 1;
            numw = numw + 1;
            
        else
            
            %%%WXij
            linex(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
            columnx(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z+1),1);
            valuex(numw) = (-1 / M.grid.dz(z)) / ( 1 / M.grid.dz(z-1) + 1 / M.grid.dz(z));
            numw = numw + 1;
            
            linex(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
            columnx(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z-1),1);
            valuex(numw) = (-1 / M.grid.dz(z-1)) / ( 1 / M.grid.dz(z-1) + 1 / M.grid.dz(z));
            numw = numw + 1;
            
            linex(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
            columnx(numw) = M.Node(M.Node(:,2)==M.grid.x(x)&M.Node(:,3)==M.grid.y(y)&M.Node(:,4)==M.grid.z(z),1);
            valuex(numw) = 1;
            numw = numw + 1;
            
        end
    end
end

L = [];

C = [];

V = [];

for y = 1 : length(M.grid.y)
    
    for x = 1  : length(M.grid.x)
        
        L = [L , linex + (y-1) * length(M.grid.x) * length(M.grid.z) + (x-1) * 1];
        
        C = [C , columnx + (y-1) * length(M.grid.x) * length(M.grid.z) + (x-1) * 1];
        
        V = [V , valuex];
        
    end
    
end

Wmz = sparse(L,C,V,M.Num_node,M.Num_node);

Wm = alpha.x * Wmx + alpha.y * Wmy + alpha.z * Wmz;
end