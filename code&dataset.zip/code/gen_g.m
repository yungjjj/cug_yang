function g = gen_g( P , K , P_ba , T , M , D , lamda , W , cond , d_obs , m_apr)
%%%%%%%%%
%% Output
% g: gradient vector

%% error between modeling vector and observation vector
w = D' * D * (log(T) - log(d_obs));

%% Calculate inv(K) * P * w
z(:,4) = pcg(K , P * w , 1e-6 , 700 );
z(:,1)=M.Node(:,2);
z(:,2)=M.Node(:,3);
z(:,3)=M.Node(:,4);

%% Calculate G' * z
GTv = gen_GTv( M , T , z);

%% Calculate gradient vector
g = P_ba * GTv + lamda * W * (log(cond(:,4)) - log(m_apr));

end

