function [ Q ] = gen_Q( M, q_down , T_up )
%%%%% Generate source vector
%% Output
% Q: source vector

Num_node = M.Num_node;
N_element = M.N_element;
Node = M.Node;
num = 1;

for ele_i = 1 : length(N_element)
    
    %% length of element
    a=abs(Node(N_element(ele_i,4),2)-Node(N_element(ele_i,3),2));
    b=abs(Node(N_element(ele_i,2),3)-Node(N_element(ele_i,6),3));
    
    %% code of element
    unit_8=N_element(ele_i,2:9);
    
    
    %% Boundary condition
    
    %% Top boundary
    if Node(unit_8(2),4)==0&& Node(unit_8(3),4)==0&& Node(unit_8(6),4)==0&& Node(unit_8(7),4)==0
            
            unit_4=[unit_8(2);unit_8(3);unit_8(6);unit_8(7)];
            
            for i=1:4
                
                line(num)=unit_4(i);column(num)=1;
                value(num)=a*b*T_up/4;
                num=num+1;
                
            end
        
    end
    
    %% Bottom boundary
    if Node(unit_8(1),4)==z(end)&& Node(unit_8(4),4)==z(end)&& Node(unit_8(5),4)==z(end)&& Node(unit_8(8),4)==z(end)
        unit_4=[unit_8(1);unit_8(4);unit_8(5);unit_8(8)];
        
        for i=1:4
            
            line(num)=unit_4(i);column(num)=1;
            value(num)=a*b*q_down/4;
            num=num+1;
            
        end
    end
    
end

Q=sparse(line,column,value,Num_node,1);