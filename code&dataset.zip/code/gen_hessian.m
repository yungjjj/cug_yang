function  Hv = gen_hessian( v , P , K , P_ba , T , M , D , lamda , W , mu_unit)
%%%%%%%
%% Input 
% v: arbitrary vector

%% Output
% Hv: Hessian-vector product

%% Calculate P_ba * v
P_bav(:,4) = P_ba * v;
P_bav(:,1)=M.Node(:,2);
P_bav(:,2)=M.Node(:,3);
P_bav(:,3)=M.Node(:,4);

%% Generate K(P_ba * v)
[ K_p ]=gen_Kd( M , P_bav , mu_unit);

%% Calculate J*v
Gv = pcg(K , K_p * T , 1e-6 , 700 );
Jv = - P * Gv;
w = D' * D * Jv;

%% Calculate P * J*v
Z(:,4) = pcg(K , P * w , 1e-6 , 700 );
Z(:,1)=M.Node(:,2);
Z(:,2)=M.Node(:,3);
Z(:,3)=M.Node(:,4);

%% Calculate G' * (P * J*v)
num = 1;

for ele_i = 1 : length(M.N_element)
    
    %% length of element
    a=abs(M.Node(M.N_element(ele_i,4),2)-M.Node(M.N_element(ele_i,3),2));
    b=abs(M.Node(M.N_element(ele_i,2),3)-M.Node(M.N_element(ele_i,6),3));
    c=abs(M.Node(M.N_element(ele_i,2),4)-M.Node(M.N_element(ele_i,3),4));

    %% code of element
    unit_8=M.N_element(ele_i,2:9);
    
    for m = 1 : 8    
        
        for i=1:8
            
            for j=1:i
                
                alfa=mu_unit(i,2)*mu_unit(j,2)*(3+mu_unit(i,3)*mu_unit(j,3)+mu_unit(i,3)*mu_unit(m,3)+mu_unit(j,3)*mu_unit(m,3))*(3+mu_unit(i,4)*mu_unit(j,4)+mu_unit(i,4)*mu_unit(m,4)+mu_unit(j,4)*mu_unit(m,4))/4;
                beta=mu_unit(i,3)*mu_unit(j,3)*(3+mu_unit(i,2)*mu_unit(j,2)+mu_unit(i,2)*mu_unit(m,2)+mu_unit(j,2)*mu_unit(m,2))*(3+mu_unit(i,4)*mu_unit(j,4)+mu_unit(i,4)*mu_unit(m,4)+mu_unit(j,4)*mu_unit(m,4))/4;
                gama=mu_unit(i,4)*mu_unit(j,4)*(3+mu_unit(i,2)*mu_unit(j,2)+mu_unit(i,2)*mu_unit(m,2)+mu_unit(j,2)*mu_unit(m,2))*(3+mu_unit(i,3)*mu_unit(j,3)+mu_unit(i,3)*mu_unit(m,3)+mu_unit(j,3)*mu_unit(m,3))/4;

                A = (b*c/a*alfa+a*c/b*beta+a*b/c*gama)/288;
                
                if i==j
                    line(num)=unit_8(m);column(num)=1;
                    value(num)=Z(unit_8(i),4)*T(unit_8(j))*A;
                    num=num+1;
                else
                    line(num)=unit_8(m);column(num)=1;
                    value(num)=Z(unit_8(i),4)*T(unit_8(j))*A;
                    num=num+1;
                    line(num)=unit_8(m);column(num)=1;
                    value(num)=Z(unit_8(j),4)*T(unit_8(i))*A;
                    num=num+1;
                end
            end
        end

    end
    
end
GTv=-sparse(line,column,value,M.Num_node,1);

%% Calculate J' * W * J * v
JTy = P_ba * GTv;

%% hessian-vector product
Hv = JTy + lamda * W * v;

end

