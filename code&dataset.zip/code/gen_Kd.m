function [ K ] = gen_Kd( M, cond , mu_unit)
%%%%% Generate K(v)
%% Output
% K: K(v)

Num_node = M.Num_node;
N_element = M.N_element;
Node = M.Node;
num = 1;

for ele_i = 1 : length(N_element)

    %% length of element
    a=abs(Node(N_element(ele_i,4),2)-Node(N_element(ele_i,3),2));
    b=abs(Node(N_element(ele_i,2),3)-Node(N_element(ele_i,6),3));
    c=abs(Node(N_element(ele_i,2),4)-Node(N_element(ele_i,3),4));
    
    %% code of element
    unit_8=N_element(ele_i,2:9);

    for i=1:8
        for j=1:i
            for l=1:8
                alfa(l)=mu_unit(i,2)*mu_unit(j,2)*(3+mu_unit(i,3)*mu_unit(j,3)+mu_unit(i,3)*mu_unit(l,3)+mu_unit(j,3)*mu_unit(l,3))*(3+mu_unit(i,4)*mu_unit(j,4)+mu_unit(i,4)*mu_unit(l,4)+mu_unit(j,4)*mu_unit(l,4))/4;
                beta(l)=mu_unit(i,3)*mu_unit(j,3)*(3+mu_unit(i,2)*mu_unit(j,2)+mu_unit(i,2)*mu_unit(l,2)+mu_unit(j,2)*mu_unit(l,2))*(3+mu_unit(i,4)*mu_unit(j,4)+mu_unit(i,4)*mu_unit(l,4)+mu_unit(j,4)*mu_unit(l,4))/4;
                gama(l)=mu_unit(i,4)*mu_unit(j,4)*(3+mu_unit(i,2)*mu_unit(j,2)+mu_unit(i,2)*mu_unit(l,2)+mu_unit(j,2)*mu_unit(l,2))*(3+mu_unit(i,3)*mu_unit(j,3)+mu_unit(i,3)*mu_unit(l,3)+mu_unit(j,3)*mu_unit(l,3))/4;
            end

            if i==j
                line(num)=unit_8(i);column(num)=unit_8(j);
                value(num)=(b*c/a*alfa+a*c/b*beta+a*b/c*gama)*[cond(unit_8(1),4);cond(unit_8(2),4);cond(unit_8(3),4);cond(unit_8(4),4);cond(unit_8(5),4);cond(unit_8(6),4);cond(unit_8(7),4);cond(unit_8(8),4)]/288;
                num=num+1;
            else
                line(num)=unit_8(i);column(num)=unit_8(j);
                value(num)=(b*c/a*alfa+a*c/b*beta+a*b/c*gama)*[cond(unit_8(1),4);cond(unit_8(2),4);cond(unit_8(3),4);cond(unit_8(4),4);cond(unit_8(5),4);cond(unit_8(6),4);cond(unit_8(7),4);cond(unit_8(8),4)]/288;
                num=num+1;
                line(num)=unit_8(j);column(num)=unit_8(i);
                value(num)=(b*c/a*alfa+a*c/b*beta+a*b/c*gama)*[cond(unit_8(1),4);cond(unit_8(2),4);cond(unit_8(3),4);cond(unit_8(4),4);cond(unit_8(5),4);cond(unit_8(6),4);cond(unit_8(7),4);cond(unit_8(8),4)]/288;
                num=num+1;
            end
        end
    end
    
end

K=sparse(line,column,value,Num_node,Num_node);