function [ N_element , Node, Num_node ] = gen_mesh( M )
%%%%%Generate mesh coordinate

dx=M.grid.dx;
dy=M.grid.dy;
dz=M.grid.dz;
NY=length(dy);
NZ=length(dz);
NX=length(dx);
Num_ele=NX*NY*NZ;
Num_node=(NX+1)*(NY+1)*(NZ+1);
Node=zeros(Num_node,4);
N_element=zeros(Num_ele,11);

%% coordinate of node
n=1;
for ee = 1:NY+1
    for e = 1:NZ+1
        for ii = 1:NX+1
            Node(n,1)=n;
            Node(n,2)=M.grid.x(ii);
            Node(n,3)=M.grid.y(ee);
            Node(n,4)=M.grid.z(e);           
            n=n+1;
        end
    end
end


%% number of node
n=1;
for ee = 1:NY
    for e = 1:NZ
        for ii = 1:NX
            
            j = ii+(e-1)*(NX+1)+(ee-1)*((NX+1)*(NZ+1));
            i = j+NX+1;
            l = j+1;
            m = j+NX+2;
            
            p = j+((NX+1)*(NZ+1));
            q = j+((NX+1)*(NZ+1))+1;
            o = j+((NX+1)*(NZ+1))+NX+1;
            r = j+((NX+1)*(NZ+1))+NX+1+1;
            N_element(n,1)=n;
            N_element(n,2)=i;
            N_element(n,3)=j;
            N_element(n,4)=l;
            N_element(n,5)=m;
            N_element(n,6)=o;
            N_element(n,7)=p;
            N_element(n,8)=q;
            N_element(n,9)=r;
            N_element(n,10)=n;
            N_element(n,11)=1;
            n=n+1;
            
        end
    end
end

end

