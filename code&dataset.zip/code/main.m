clear
clc
tic

%% Input observational data
load d_obs

%% Input Regularization factor
lamda=5;

%% Input model node
load M

%% Generate model mesh
[ M.N_element , M.Node , M.Num_node ]=gen_mesh( M );

%% Input initial thermal conductivity distribution
cond=ones(M.Num_node,4)*3;
cond(:,1)=M.Node(:,2);
cond(:,2)=M.Node(:,3);
cond(:,3)=M.Node(:,4);

%% Local coordinate system
mu_unit=[1 , -1 , -1 , 1;...
    2 , -1 , -1 , -1;...
    3 , 1 , -1 , -1;...
    4 , 1 , -1 , 1;...
    5 , -1 , 1 , 1;...
    6 , -1 , 1 , -1;...
    7 , 1 , 1 , -1;...
    8 , 1 , 1 , 1];

%% A priori information
m_apr = cond(:,4);

%% weights in three directions of roughness matrix
alpha.x = 1;
alpha.y = 1 ;
alpha.z = 0.001;

%% Generate roughness matrix
[ Wm , Wmx , Wmy , Wmz ] = gen_Wm( M , alpha );

W = Wm' * Wm;

%% Top surface of model
T_up = 15;

%% Bottom of model
q_down = 0.05;

%% Generate source
Q = gen_Q( M , q_down , T_up );

%% sparse Wm' * Wm
H_p=diag(sparse(1./diag(W)));

%% Start iteration 
for iteration = 1 : 20
    %% Forward modeling
    [ T , D , error(iteration) , K] = heat3D_parSIM( cond , M , d_obs , Q );
    
    %% diag+sparse temperature vector
    P = diag(sparse(1./T));
    
    %% diag+sparse thermal conductivity vector
    P_ba = diag(sparse(cond(:,4)));
    
    %% Generate hessian-vector product
    Hv = @(v) gen_hessian( v , P , K , P_ba , T , M , D , lamda , W , mu_unit);
    
    %% Generate gradient vector
    g = -gen_g( P , K , P_ba , T , M , D , lamda , W , cond , d_obs , m_apr);
    
    %% Calculate H * v = g
    deltam = pcg(Hv , g , 1e-6 , 20 , H_p);
    
    %% storage model update direction of each iteration
    delta( : , iteration+1) = deltam;
    
    %% Armijo rule
    alpha_d = armijo(  M , D , lamda , cond , g , Q , d_obs , m_apr , Wm , deltam);
    
    %% Obtain the model vector under this iteration
    cond(:,4) = exp ( log( cond(:,4)) + alpha_d * deltam );
    
    %% Reduce the regularization factor
    lamda=lamda*0.5;
    
    %% storage model vector of each iteration
    COND(:,iteration) = cond(:,4);
    
end

%% save the result

save('result.mat', 'COND', 'M', 'T', 'error')

toc