1. This code is a 3D thermal conductivity prediction based on temperature field estimation.
2. The program is written in language MATLAB.
3. "d_obs.mat" is the observation data file
    % The data is the temperature distribution based on the mesh coordinate
4. "M.mat" is the model mesh file
    % "x" is the coordinate in x direction
    % "y" is the coordinate in y direction
    % "z" is the coordinate in z direction
    % "dx" is the length of element in x direction
    % "dy" is the length of element in y direction
    % "dz" is the length of element in z direction
5. Running operation of code
   It can be run only by giving the "d_obs.mat" and "M.mat".
   The predicted results can be obtain by running the main programe file "main.m". 
   gen_mesh.m is the subroutine for generating the mesh coordinate;
   gen_K.m and gen_Kd.m are used to generate the coefficient matrices;
   gen_Wm.m is the subroutine for generating the roughness matrix;
   gen_g.m and gen_hessian.m are used to generate gradient vector and hessian matrix, respectively;
   gen_GTv.m is used to generate G' * v;
   gen_Q.m is used to generate source vector;
   armijo.m is the routine for armijo rule;
   gen_fia.m is used to generate objective function;
   heat3D_parSIM.m is the subroutine for calculating the temperature distribution;
   gen_obs.m is forward modeling, users can modify the parameters to get different results.